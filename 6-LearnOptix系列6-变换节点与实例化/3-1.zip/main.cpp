#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glew.h>
#  if defined( _WIN32 )
#    include <GL/wglew.h>
#    include <GL/freeglut.h>
#  else
#    include <GL/glut.h>
#  endif
#endif

#include <optixu/optixpp_namespace.h>
#include <optixu/optixu_math_stream_namespace.h>
#include "common.h"
#include <sutil.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

uint32_t width = 712;
uint32_t height = 512;
bool is_WH_changed = false;

#define radians(x) (x*3.14159265/180.0)

using namespace optix;

// ���״̬
float3       camera_up;
float3       camera_lookat;
float3       camera_eye;
float3       camera_front;
float3       camera_right;
// camera_dirty���������û�����ⲿ�����޸�
bool         camera_dirty = true;

// �������Fov��ͼ�񳤿���
float vfov, aspect_ratio;
void setupCamera();
void updateCamera();
void createGeometry();
void setupLights();

// ȫ�ֱ��������幤����
// ����������Ӧ�Ĺ�������������SDK�¶��ж�ӦĿ¼
// ���ڴ����Ϊoptix��GPU�����.cu�ļ�
const char* const Project_NAME = "optixTest";

using namespace optix;
Context        context = 0;
Buffer result_buffer;
Buffer accum_buffer;

Buffer  tex_buffer;
TextureSampler tex_sampler;
void* tex_data_ptr;



Buffer getOutputBuffer();

void displayBuffer(RTbuffer bufferInput);

void glutInitialize(int* argc, char** argv);
void createContext();

void glutDisplay();
void glutResize(int w, int h);
void glutMousePress(int button, int state, int x, int y);
void glutMouseMotion(int x, int y);
void glutKeyboardPress(unsigned char k, int x, int y);
void registerExitHandler();

// Mouse state
int2       mouse_prev_pos;
int        mouse_button;
// �����ƫ���͸�����
float pitch, yaw;

void glutRun();

int main(int argc, char** argv)
{
	try
	{
		glutInitialize(&argc, argv);

		// ��������
		createContext();
		setupCamera();
		updateCamera();
		createGeometry();
		setupLights();

		glutRun();
		
		return 0;
	}
	catch (const std::exception& e)
	{
		std::cerr << "OptiX Error: '" << e.what() << "'\n";
		system("pause");
		exit(1);
	}
	return 0;
}

// ********************************************************** 
// ���´��붼�ǳ�����ʼ������
// ********************************************************** 

// ����Context
void createContext()
{
	context = optix::Context::create();
	// 1�ֹ���(��ʱ����2�֣��������+��Ӱ����)
	context->setRayTypeCount(2); 
	// ����context������ڵ�
	context->setEntryPointCount(1);
	context->setStackSize(2800);
	context->setMaxTraceDepth(12);

	//����Buffer
	result_buffer = context->createBuffer(RT_BUFFER_OUTPUT, RT_FORMAT_UNSIGNED_BYTE4, width, height);
	context["result_buffer"]->set(result_buffer);
	context["frame"]->setUint(0u);
	context["max_depth"]->setInt(10);
	context["scene_epsilon"]->setFloat(1.e-4f);

	
	accum_buffer = context->createBuffer(RT_BUFFER_INPUT_OUTPUT | RT_BUFFER_GPU_LOCAL,
		RT_FORMAT_FLOAT4, width, height);
	context["accum_buffer"]->set(accum_buffer);

	//����Shader
	const char *ptx = sutil::getPtxString(Project_NAME, "camera.cu");

	context->setRayGenerationProgram(0, context->createProgramFromPTXString(ptx, "camera_sample"));

	// Exception program
	Program exception_program = context->createProgramFromPTXString(ptx, "exception");
	context->setExceptionProgram(0, exception_program);
	context["bad_color"]->setFloat(1.0f, 0.0f, 1.0f);

	// Miss program
	const char *ptx2 = sutil::getPtxString(Project_NAME, "background.cu");
	context->setMissProgram(0, context->createProgramFromPTXString(ptx2, "envmap_miss"));
	context["bg_color"]->setFloat(0.34f, 0.55f, 0.85f);
}

// ��������͸������
void setupCamera()
{
	camera_eye = make_float3(8.0f, 2.0f, -4.0f);

	pitch = 0;
	yaw = 170;
	
	camera_front.x = cos(radians(yaw)) * cos(radians(pitch));
	camera_front.y = sin(radians(pitch));
	camera_front.z = sin(radians(yaw)) * cos(radians(pitch));
	camera_front = normalize(camera_front);

	camera_lookat = camera_eye + camera_front;

	camera_up = make_float3(0.0f, 1.0f, 0.0f);
}
void updateCamera() {
	vfov = 45.0f;
	aspect_ratio = static_cast<float>(width) /
		static_cast<float>(height);

	float3 camera_u, camera_v, camera_w;
	sutil::calculateCameraVariables(
		camera_eye, camera_lookat, camera_up, vfov, aspect_ratio,
		camera_u, camera_v, camera_w, true);

	camera_right = camera_u;

	context["eye"]->setFloat(camera_eye);
	context["U"]->setFloat(camera_u);
	context["V"]->setFloat(camera_v);
	context["W"]->setFloat(camera_w);
}

// ���ɻ�Ԫ�����ɺͰ󶨲��ʡ��������ٽṹ

void createGeometry()
{
	// Create glass sphere geometry
	Geometry glass_sphere = context->createGeometry();
	glass_sphere->setPrimitiveCount(1u);

	const char *ptx = sutil::getPtxString(Project_NAME, "sphere_shell.cu");
	glass_sphere->setBoundingBoxProgram(context->createProgramFromPTXString(ptx, "bounds"));
	glass_sphere->setIntersectionProgram(context->createProgramFromPTXString(ptx, "intersect"));
	glass_sphere["center"]->setFloat(4.0f, 2.3f, -4.0f);
	glass_sphere["radius1"]->setFloat(0.96f);
	glass_sphere["radius2"]->setFloat(1.0f);

	// Metal sphere geometry
	Geometry metal_sphere = context->createGeometry();
	metal_sphere->setPrimitiveCount(1u);
	ptx = sutil::getPtxString(Project_NAME, "sphere.cu");
	metal_sphere->setBoundingBoxProgram(context->createProgramFromPTXString(ptx, "bounds"));
	metal_sphere->setIntersectionProgram(context->createProgramFromPTXString(ptx, "robust_intersect"));
	metal_sphere["sphere"]->setFloat(2.0f, 1.5f, -2.5f, 1.0f);

	// Floor geometry
	Geometry parallelogram = context->createGeometry();
	parallelogram->setPrimitiveCount(1u);
	ptx = sutil::getPtxString(Project_NAME, "parallelogram.cu");
	parallelogram->setBoundingBoxProgram(context->createProgramFromPTXString(ptx, "bounds"));
	parallelogram->setIntersectionProgram(context->createProgramFromPTXString(ptx, "intersect"));
	float3 anchor = make_float3(-16.0f, 0.01f, -8.0f);
	float3 v1 = make_float3(32.0f, 0.0f, 0.0f);
	float3 v2 = make_float3(0.0f, 0.0f, 16.0f);
	float3 normal = cross(v1, v2);
	normal = normalize(normal);
	float d = dot(normal, anchor);
	v1 *= 1.0f / dot(v1, v1);
	v2 *= 1.0f / dot(v2, v2);
	float4 plane = make_float4(normal, d);
	parallelogram["plane"]->setFloat(plane);
	parallelogram["v1"]->setFloat(v1);
	parallelogram["v2"]->setFloat(v2);
	parallelogram["anchor"]->setFloat(anchor);


	// Glass material
	ptx = sutil::getPtxString(Project_NAME, "glass.cu");
	Program glass_ch = context->createProgramFromPTXString(ptx, "closest_hit_radiance");
	Program glass_ah = context->createProgramFromPTXString(ptx, "any_hit_shadow");
	Material glass_matl = context->createMaterial();
	glass_matl->setClosestHitProgram(0, glass_ch);
	glass_matl->setAnyHitProgram(1, glass_ah);

	glass_matl["importance_cutoff"]->setFloat(1e-2f);
	glass_matl["cutoff_color"]->setFloat(0.034f, 0.055f, 0.085f);
	glass_matl["fresnel_exponent"]->setFloat(3.0f);
	glass_matl["fresnel_minimum"]->setFloat(0.1f);
	glass_matl["fresnel_maximum"]->setFloat(1.0f);
	glass_matl["refraction_index"]->setFloat(1.4f);
	glass_matl["refraction_color"]->setFloat(1.0f, 1.0f, 1.0f);
	glass_matl["reflection_color"]->setFloat(1.0f, 1.0f, 1.0f);
	glass_matl["refraction_maxdepth"]->setInt(10);
	glass_matl["reflection_maxdepth"]->setInt(5);
	const float3 extinction = make_float3(.83f, .83f, .83f);
	glass_matl["extinction_constant"]->setFloat(log(extinction.x), log(extinction.y), log(extinction.z));
	glass_matl["shadow_attenuation"]->setFloat(0.6f, 0.6f, 0.6f);

	// Metal material
	ptx = sutil::getPtxString(Project_NAME, "phong.cu");
	Program phong_ch = context->createProgramFromPTXString(ptx, "closest_hit_radiance");
	Program phong_ah = context->createProgramFromPTXString(ptx, "any_hit_shadow");
	Material metal_matl = context->createMaterial();
	metal_matl->setClosestHitProgram(0, phong_ch);
	metal_matl->setAnyHitProgram(1, phong_ah);
	metal_matl["Ka"]->setFloat(0.2f, 0.5f, 0.5f);
	metal_matl["Kd"]->setFloat(0.2f, 0.7f, 0.8f);
	metal_matl["Ks"]->setFloat(0.9f, 0.9f, 0.9f);
	metal_matl["phong_exp"]->setFloat(64);
	metal_matl["Kr"]->setFloat(0.5f, 0.5f, 0.5f);


	// Floor material for floor
	/*{
		ptx = sutil::getPtxString(Project_NAME, "checker.cu");
		Program floor_ch = context->createProgramFromPTXString(ptx, "closest_hit_radiance");
		Program floor_ah = context->createProgramFromPTXString(ptx, "any_hit_shadow");
		Material floor_matl = context->createMaterial();
		floor_matl->setClosestHitProgram(0, floor_ch);
		floor_matl->setAnyHitProgram(1, floor_ah);

		floor_matl["Kd1"]->setFloat(0.8f, 0.3f, 0.15f);
		floor_matl["Ka1"]->setFloat(0.8f, 0.3f, 0.15f);
		floor_matl["Ks1"]->setFloat(0.0f, 0.0f, 0.0f);
		floor_matl["Kd2"]->setFloat(0.9f, 0.85f, 0.05f);
		floor_matl["Ka2"]->setFloat(0.9f, 0.85f, 0.05f);
		floor_matl["Ks2"]->setFloat(0.0f, 0.0f, 0.0f);
		floor_matl["inv_checker_size"]->setFloat(32.0f, 16.0f, 1.0f);
		floor_matl["phong_exp1"]->setFloat(0.0f);
		floor_matl["phong_exp2"]->setFloat(0.0f);
		floor_matl["Kr1"]->setFloat(0.0f, 0.0f, 0.0f);
		floor_matl["Kr2"]->setFloat(0.4f, 0.4f, 0.4f);
	}*/
	ptx = sutil::getPtxString(Project_NAME, "floor.cu");
	Program floor_ch = context->createProgramFromPTXString(ptx, "closest_hit_radiance");
	Program floor_ah = context->createProgramFromPTXString(ptx, "any_hit_shadow");
	Material floor_matl = context->createMaterial();
	floor_matl->setClosestHitProgram(0, floor_ch);
	floor_matl->setAnyHitProgram(1, floor_ah);
	floor_matl["Kr"]->setFloat(0.5f, 0.5f, 0.5f);
	floor_matl["phong_exp"]->setFloat(64);

	// ����
	{
		int imgW, imgH, nrChannels;
		unsigned char *data = stbi_load("resources/floor.png", &imgW, &imgH, &nrChannels, 0);

		if (data) {
			// Create the buffer that represents the texture data
			tex_buffer = context->createBuffer(RT_BUFFER_INPUT, RT_FORMAT_UNSIGNED_BYTE4, imgW, imgH);

			tex_data_ptr = tex_buffer->map();
			memcpy(tex_data_ptr, data, imgW * imgH * 4 * sizeof(unsigned char));
			tex_buffer->unmap();

			// Create the texture sampler
			tex_sampler = context->createTextureSampler();
			tex_sampler->setWrapMode(0, RT_WRAP_CLAMP_TO_EDGE);
			tex_sampler->setWrapMode(1, RT_WRAP_CLAMP_TO_EDGE);
			tex_sampler->setFilteringModes(RT_FILTER_LINEAR, RT_FILTER_LINEAR, RT_FILTER_NONE);
			tex_sampler->setIndexingMode(RT_TEXTURE_INDEX_NORMALIZED_COORDINATES);
			tex_sampler->setReadMode(RT_TEXTURE_READ_NORMALIZED_FLOAT);
			tex_sampler->setMaxAnisotropy(1.0f);
			tex_sampler->setMipLevelCount(1);
			tex_sampler->setArraySize(1);
			tex_sampler->setBuffer(tex_buffer);
			
			context["input_texture"]->setTextureSampler(tex_sampler);
		}

		stbi_image_free(data);
	}

	// ������
	{
		const float3 default_color = make_float3(1.0f, 1.0f, 1.0f);
		const std::string texpath = "./resources/CedarCity.hdr";
		context["envmap"]->setTextureSampler(sutil::loadTexture(context, texpath, default_color));
	}

	// Create GIs for each piece of geometry
	std::vector<GeometryInstance> gis;
	gis.push_back(context->createGeometryInstance(glass_sphere, &glass_matl, &glass_matl + 1));
	gis.push_back(context->createGeometryInstance(metal_sphere, &metal_matl, &metal_matl + 1));

	// Place all in group
	GeometryGroup geometrygroup = context->createGeometryGroup();
	geometrygroup->setChildCount(static_cast<unsigned int>(gis.size()));
	geometrygroup->setChild(0, gis[0]);
	geometrygroup->setChild(1, gis[1]);
	geometrygroup->setAcceleration(context->createAcceleration("NoAccel"));

	// define group
	Group group = context->createGroup();
	group->setChildCount(20);
	for (int count = 0; count < 20; ++count) {
		float r1 = (float)rand() / (float)(1 + RAND_MAX);
		float r2 = (float)rand() / (float)(1 + RAND_MAX);
		
		Transform transform = context->createTransform();
		float m[16] = {
			1.0f, 0.0f, 0.0f, (r1 * 32.0f - 16.0f),
			0.0f, 1.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 1.0f, (r2 * 16.0f - 8.0f),
			0.0f, 0.0f, 0.0f, 1.0f
		};
		transform->setMatrix(false, m, NULL);
		transform->setChild(geometrygroup);

		group->setChild(count, transform);

	}
	group->setAcceleration(context->createAcceleration("Trbvh"));

	GeometryInstance gis_floor = context->createGeometryInstance(parallelogram, &floor_matl, &floor_matl + 1);
	GeometryGroup geometrygroup2 = context->createGeometryGroup();
	geometrygroup2->setChildCount(1);
	geometrygroup2->setChild(0, gis_floor);
	geometrygroup2->setAcceleration(context->createAcceleration("NoAccel"));


	Group top_group = context->createGroup();
	top_group->setChildCount(2);
	top_group->setChild(0, group);
	top_group->setChild(1, geometrygroup2);
	top_group->setAcceleration(context->createAcceleration("NoAccel"));

	context["top_object"]->set(top_group);
	context["top_shadower"]->set(top_group);

}

void setupLights()
{

	BasicLight lights[] = {
		{ make_float3(60.0f, 40.0f, 0.0f), make_float3(1.0f, 1.0f, 1.0f), 1 }
	};

	Buffer light_buffer = context->createBuffer(RT_BUFFER_INPUT);
	light_buffer->setFormat(RT_FORMAT_USER);
	light_buffer->setElementSize(sizeof(BasicLight));
	light_buffer->setSize(sizeof(lights) / sizeof(lights[0]));
	memcpy(light_buffer->map(), lights, sizeof(lights));
	light_buffer->unmap();

	context["lights"]->set(light_buffer);
	context["ambient_light_color"]->setFloat(0.4f, 0.4f, 0.4f);
}


// ********************************************************** 
// ���´��붼����Ⱦ��غ���
// ********************************************************** 

void glutDisplay()
{

	static unsigned int accumulation_frame = 0;
	if (camera_dirty || is_WH_changed) {
		updateCamera();

		accumulation_frame = 0;

		is_WH_changed = false;
		camera_dirty = false;
	}

	context["frame"]->setUint(accumulation_frame++);

	//������0�����
	context->launch(0, width, height);

	displayBuffer(getOutputBuffer()->get());

	glutSwapBuffers();
}
void glutRun()
{
	// Initialize GL state                                                            
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, 1, 0, 1, -1, 1);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glViewport(0, 0, width, height);

	glutShowWindow();
	glutReshapeWindow(width, height);

	// register glut callbacks
	glutDisplayFunc(glutDisplay);
	glutIdleFunc(glutDisplay);
	glutReshapeFunc(glutResize);
	glutMouseFunc(glutMousePress);
	glutMotionFunc(glutMouseMotion);
	glutKeyboardFunc(glutKeyboardPress);

	registerExitHandler();

	glutMainLoop();
}

// ********************************************************** 
// ���´��붼��OpenGL�������ɺͽ�������
// ********************************************************** 

void glutInitialize(int* argc, char** argv)
{
	glutInit(argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_ALPHA | GLUT_DEPTH | GLUT_DOUBLE);
	glutInitWindowSize(width, height);
	glutInitWindowPosition(100, 100);
	glutCreateWindow(Project_NAME);
	glutHideWindow();
}
void glutResize(int w, int h)
{
	if (w == (int)width && h == (int)height) return;
	width = w;
	height = h;

	is_WH_changed = true;
	camera_dirty = true;

	sutil::resizeBuffer(getOutputBuffer(), width, height);
	sutil::resizeBuffer(context["accum_buffer"]->getBuffer(), width, height);
	
	glViewport(0, 0, width, height);

	glutPostRedisplay();
}
void destroyContext()
{
	// ���޹���
}
void registerExitHandler()
{
	// this function is freeglut-only
	glutCloseFunc(destroyContext);
}
void glutMousePress(int button, int state, int x, int y)
{
	if (state == GLUT_DOWN)
	{
		mouse_button = button;
		mouse_prev_pos = make_int2(x, y);
	}
	else
	{
		// nothing
	}
}
void glutMouseMotion(int x, int y)
{
	if (mouse_button == GLUT_RIGHT_BUTTON)
	{
		const float dx = static_cast<float>(x - mouse_prev_pos.x) /
			static_cast<float>(width);
		const float dy = static_cast<float>(y - mouse_prev_pos.y) /
			static_cast<float>(height);
		const float dmax = fabsf(dx) > fabs(dy) ? dx : dy;
		const float scale = fminf(dmax, 0.9f);
		camera_eye = camera_eye + camera_front * scale;
		camera_lookat = camera_eye + camera_front;
		camera_dirty = true;
	}
	else if (mouse_button == GLUT_LEFT_BUTTON)
	{
		const float2 from = { static_cast<float>(mouse_prev_pos.x),
			static_cast<float>(mouse_prev_pos.y) };
		const float2 to = { static_cast<float>(x),
			static_cast<float>(y) };

		const float scale = 0.1f;
		yaw += (to.x - from.x) * scale;
		pitch -= (to.y - from.y) * scale;

		if (pitch > 89.0f)
			pitch = 89.0f;
		if (pitch < -89.0f)
			pitch = -89.0f;

		if (yaw > 360.f)
			yaw -= 360.f;
		if (yaw < -360.0f)
			yaw += 360.0f;

		camera_front.x = cos(radians(yaw)) * cos(radians(pitch));
		camera_front.y = sin(radians(pitch));
		camera_front.z = sin(radians(yaw)) * cos(radians(pitch));
		camera_front = normalize(camera_front);

		camera_lookat = camera_eye + camera_front;

		camera_dirty = true;
	}

	mouse_prev_pos = make_int2(x, y);
}
void glutKeyboardPress(unsigned char k, int x, int y)
{
	switch (k)
	{
	case('q') :
	case(27) : // ESC
	{
		destroyContext();
		exit(0);
	}
	case('w') :
	{
		camera_eye = camera_eye + camera_front * 0.1;
		camera_lookat = camera_eye + camera_front;
		camera_dirty = true;
		break;
	}
	case('s') :
	{
		camera_eye = camera_eye - camera_front * 0.1;
		camera_lookat = camera_eye + camera_front;
		camera_dirty = true;
		break;
	}
	case('a') :
	{
		camera_eye = camera_eye - camera_right * 0.1;
		camera_lookat = camera_eye + camera_front;
		camera_dirty = true;
		break;
	}
	case('d') :
	{
		camera_eye = camera_eye + camera_right * 0.1;
		camera_lookat = camera_eye + camera_front;
		camera_dirty = true;
		break;
	}
	case('f') :
	{
		camera_eye = camera_eye + make_float3(0.0,1.0,0.0) * 0.1;
		camera_lookat = camera_eye + camera_front;
		camera_dirty = true;
		break;
	}
	}
}

// ********************************************************** 
// ���´��붼���������ɺ�ת��Optix��BufferΪOpenGL��Buffer
// ********************************************************** 

Buffer getOutputBuffer()
{
	return context["result_buffer"]->getBuffer();
}

/**
*  ��ȡ����buffer���ͣ�
*  GL_BGRA/GL_RGBA/GL_RGB/GL_BGR/GL_LUMINANCE
*/ 
GLenum glFormatFromBufferFormat(bufferPixelFormat pixel_format, RTformat buffer_format)
{
	if (buffer_format == RT_FORMAT_UNSIGNED_BYTE4)
	{
		switch (pixel_format)
		{
		case BUFFER_PIXEL_FORMAT_DEFAULT:
			return GL_BGRA;
		case BUFFER_PIXEL_FORMAT_RGB:
			return GL_RGBA;
		case BUFFER_PIXEL_FORMAT_BGR:
			return GL_BGRA;
		default:
			throw Exception("Unknown buffer pixel format");
		}
	}
	else if (buffer_format == RT_FORMAT_FLOAT4)
	{
		switch (pixel_format)
		{
		case BUFFER_PIXEL_FORMAT_DEFAULT:
			return GL_RGBA;
		case BUFFER_PIXEL_FORMAT_RGB:
			return GL_RGBA;
		case BUFFER_PIXEL_FORMAT_BGR:
			return GL_BGRA;
		default:
			throw Exception("Unknown buffer pixel format");
		}
	}
	else if (buffer_format == RT_FORMAT_FLOAT3)
		switch (pixel_format)
		{
		case BUFFER_PIXEL_FORMAT_DEFAULT:
			return GL_RGB;
		case BUFFER_PIXEL_FORMAT_RGB:
			return GL_RGB;
		case BUFFER_PIXEL_FORMAT_BGR:
			return GL_BGR;
		default:
			throw Exception("Unknown buffer pixel format");
		}
	else if (buffer_format == RT_FORMAT_FLOAT)
		return GL_LUMINANCE;
	else
		throw Exception("Unknown buffer format");
}
/**
*  ��buffer��ʽת��ΪOpenGL��ʽ
*/ 
void displayBuffer(RTbuffer bufferInput)
{
	// The pixel format of the buffer or 0 to use the default for the pixel type
	bufferPixelFormat format = BUFFER_PIXEL_FORMAT_DEFAULT; 
	bool disable_srgb_conversion = false;
	optix::Buffer buffer = Buffer::take(bufferInput);

	// Query buffer information
	RTsize buffer_width_rts, buffer_height_rts;
	buffer->getSize(buffer_width_rts, buffer_height_rts);
	uint32_t width = static_cast<int>(buffer_width_rts);
	uint32_t height = static_cast<int>(buffer_height_rts);
	RTformat buffer_format = buffer->getFormat();

	GLboolean use_SRGB = GL_FALSE;
	if (!disable_srgb_conversion && (buffer_format == RT_FORMAT_FLOAT4 || buffer_format == RT_FORMAT_FLOAT3))
	{
		glGetBooleanv(GL_FRAMEBUFFER_SRGB_CAPABLE_EXT, &use_SRGB);
		if (use_SRGB)
			glEnable(GL_FRAMEBUFFER_SRGB_EXT);
	}

	static unsigned int gl_tex_id = 0;
	if (!gl_tex_id)
	{
		glGenTextures(1, &gl_tex_id);
		glBindTexture(GL_TEXTURE_2D, gl_tex_id);

		// Change these to GL_LINEAR for super- or sub-sampling
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

		// GL_CLAMP_TO_EDGE for linear filtering, not relevant for nearest.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	}

	glBindTexture(GL_TEXTURE_2D, gl_tex_id);

	// send PBO or host-mapped image data to texture
	const unsigned pboId = buffer->getGLBOId();
	GLvoid* imageData = 0;
	if (pboId)
		glBindBuffer(GL_PIXEL_UNPACK_BUFFER, pboId);
	else
		imageData = buffer->map(0, RT_BUFFER_MAP_READ);

	RTsize elmt_size = buffer->getElementSize();
	if (elmt_size % 8 == 0) glPixelStorei(GL_UNPACK_ALIGNMENT, 8);
	else if (elmt_size % 4 == 0) glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	else if (elmt_size % 2 == 0) glPixelStorei(GL_UNPACK_ALIGNMENT, 2);
	else                          glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	GLenum pixel_format = glFormatFromBufferFormat(format, buffer_format);

	if (buffer_format == RT_FORMAT_UNSIGNED_BYTE4)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, pixel_format, GL_UNSIGNED_BYTE, imageData);
	else if (buffer_format == RT_FORMAT_FLOAT4)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F_ARB, width, height, 0, pixel_format, GL_FLOAT, imageData);
	else if (buffer_format == RT_FORMAT_FLOAT3)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB32F_ARB, width, height, 0, pixel_format, GL_FLOAT, imageData);
	else if (buffer_format == RT_FORMAT_FLOAT)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE32F_ARB, width, height, 0, pixel_format, GL_FLOAT, imageData);
	else
		throw Exception("Unknown buffer format");

	if (pboId)
		glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
	else
		buffer->unmap();

	// 1:1 texel to pixel mapping with glOrtho(0, 1, 0, 1, -1, 1) setup:
	// The quad coordinates go from lower left corner of the lower left pixel
	// to the upper right corner of the upper right pixel.
	// Same for the texel coordinates.

	glEnable(GL_TEXTURE_2D);

	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 0.0f);
	glVertex2f(0.0f, 0.0f);

	glTexCoord2f(1.0f, 0.0f);
	glVertex2f(1.0f, 0.0f);

	glTexCoord2f(1.0f, 1.0f);
	glVertex2f(1.0f, 1.0f);

	glTexCoord2f(0.0f, 1.0f);
	glVertex2f(0.0f, 1.0f);
	glEnd();

	glDisable(GL_TEXTURE_2D);

	if (use_SRGB)
		glDisable(GL_FRAMEBUFFER_SRGB_EXT);
}





















