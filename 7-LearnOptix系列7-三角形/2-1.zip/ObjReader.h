#pragma once
/*
* Copyright (c) 2023, Dezeming Family. All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*  * Redistributions of source code must retain the above copyright
*    notice, this list of conditions and the following disclaimer.
*  * Redistributions in binary form must reproduce the above copyright
*    notice, this list of conditions and the following disclaimer in the
*    documentation and/or other materials provided with the distribution.
*  * Neither the name of Dezeming Family nor the names of its
*    contributors may be used to endorse or promote products derived
*    from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
* PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
* OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef __ObjReader_h__
#define __ObjReader_h__

#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>

#include <optixu/optixpp_namespace.h>
#include <optixu/optixu_math_stream_namespace.h>
#include "common.h"
#include <sutil.h>

struct Vertice {
	Vertice(float v1, float v2, float v3) {
		v[0] = v1;
		v[1] = v2;
		v[2] = v3;
	}
	float v[3];
};
struct VTexture {
	VTexture(float vt1, float vt2) {
		vt[0] = vt1;
		vt[1] = vt2;
	}
	float vt[2];
};
struct VNormal {
	VNormal(float vn1, float vn2, float vn3) {
		vn[0] = vn1;
		vn[1] = vn2;
		vn[2] = vn3;
	}
	float vn[3];
};
struct Face {
	// v/vt/vn
	int v[3];
	int vt[3];
	int vn[3];
};

class ObjReader {
public:
	ObjReader(){
		hasVt = true;
		hasVn = true;
		VDataArray = nullptr;
		FacesArray = nullptr;

		bbox_max = optix::make_float3(-10000, -10000, -10000);
		bbox_min = optix::make_float3(10000, 10000, 10000);
	}
	~ObjReader() {
		if (VDataArray) {
			delete[] VDataArray;
		}
		if (FacesArray) {
			delete[] FacesArray;
		}
		VDataArray = nullptr;
		FacesArray = nullptr;
		vertices.clear();
		UVs.clear();
		normals.clear();
		faces.clear();

	}

	optix::Buffer tri_indicesBuffer;
	optix::Buffer mat_indicesBuffer;
	optix::Buffer positionsBuffer;
	optix::Buffer normalsBuffer;
	optix::Buffer texcoordsBuffer;
	optix::Buffer norm_indicesBuffer;
	optix::Buffer tex_indicesBuffer;

	std::vector<Vertice> vertices;
	std::vector<VTexture> UVs;
	std::vector<VNormal> normals;
	std::vector<Face> faces;

	optix::Program pro_attri;

	optix::GeometryTriangles geom_tri;
	optix::GeometryInstance geom_instance;

	// ��ʱ����
	float* VDataArray;
	int* FacesArray;

	optix::float3                bbox_min;
	optix::float3                bbox_max;

	bool hasVt;
	bool hasVn;

	void Stringsplit(std::string str, const const char split)
	{
		std::istringstream iss(str);  
		std::string token;
		getline(iss, token, ' ');
		while (getline(iss, token, split)) {
			std::cout << token << " ";
		}
		std::cout << std::endl;
	}

	bool loadObj(std::string filename) {
		std::ifstream file(filename);
		if (!file.is_open()) {
			return false;
		}

		vertices.clear();
		UVs.clear();
		normals.clear();
		faces.clear();

		std::string line;
		while (!file.eof()) {
			std::getline(file, line);
			if (line[0] == 'v' && line[1] == ' ') {
				std::istringstream iss(line);
				std::string token;
				getline(iss, token, ' ');

				std::vector<float> temp;
				while (getline(iss, token, ' ')) {
					temp.push_back(std::stof(token));
				}
				if (temp.size() == 3) {
					if (bbox_max.x < temp[0]) bbox_max.x = temp[0];
					if (bbox_max.y < temp[1]) bbox_max.y = temp[1];
					if (bbox_max.z < temp[2]) bbox_max.z = temp[2];
					if (bbox_min.x > temp[0]) bbox_min.x = temp[0];
					if (bbox_min.y > temp[1]) bbox_min.y = temp[1];
					if (bbox_min.z > temp[2]) bbox_min.z = temp[2];

					vertices.push_back(Vertice(temp[0], temp[1], temp[2]));
				}
			}
			else if (line[0] == 'v' && line[1] == 't') {
				std::istringstream iss(line);
				std::string token;
				getline(iss, token, ' ');

				std::vector<float> temp;
				while (getline(iss, token, ' ')) {
					temp.push_back(std::stof(token));
				}
				if (temp.size() == 2) {
					UVs.push_back(VTexture(temp[0], temp[1]));
				}
			}
			else if (line[0] == 'v' && line[1] == 'n') {
				std::istringstream iss(line);
				std::string token;
				getline(iss, token, ' ');

				std::vector<float> temp;
				while (getline(iss, token, ' ')) {
					temp.push_back(std::stof(token));
				}
				if (temp.size() == 3) {
					normals.push_back(VNormal(temp[0], temp[1], temp[2]));
				}
			}
			else if (line[0] == 'f') {
				std::istringstream iss(line);
				std::string token;
				getline(iss, token, ' ');

				std::vector<std::string> temp;
				while (getline(iss, token, ' ')) {
					temp.push_back(token);
				}
				if (temp.size() == 3) {
					std::vector<int> dat_f;
					bool flag = true;
					for (int i = 0; i < 3; i++) {
						std::istringstream iss2(temp[i]);
						std::string token2;
						while (getline(iss2, token2, '/')) {
							dat_f.push_back((std::stoi(token2)));
						}
					}
					if (dat_f.size() == 9) {
						Face f;
						f.v[0] = dat_f[0]-1; f.v[1] = dat_f[3]-1; f.v[2] = dat_f[6]-1;
						f.vt[0] = dat_f[1]-1; f.vt[1] = dat_f[4]-1; f.vt[2] = dat_f[7]-1;
						f.vn[0] = dat_f[2]-1; f.vn[1] = dat_f[5]-1; f.vn[2] = dat_f[8]-1;
						hasVn = true;
						hasVt = true;
						faces.push_back(f);
					}else if (dat_f.size() == 6) {
						
					}else if (dat_f.size() == 3) {
						Face f;
						f.v[0] = dat_f[0] - 1; f.v[1] = dat_f[1] - 1; f.v[2] = dat_f[2] - 1;
						hasVn = false;
						hasVt = false;
						faces.push_back(f);
					}
				}
			}
			else {
				// ������Ϣ���ݲ�����
			}

		}

		std::cout << "vertices: " << vertices.size() << std::endl;

		std::cout << "UVs: " << UVs.size() << std::endl;
		std::cout << "normals: " << normals.size() << std::endl;
		std::cout << "faces: " << faces.size() << std::endl;

		std::cout << "bbox_max: " << bbox_max.x << " " << bbox_max.y << " " << bbox_max.z << " " << std::endl;
		std::cout << "bbox_min: " << bbox_min.x << " " << bbox_min.y << " " << bbox_min.z << " " << std::endl;

		return true;
	}

	// scale: ����ֵ����
	bool toOptix(optix::Context &context, optix::Material& matl, float scale = 1.0f) {

		// ����Buffer
		{
			using namespace optix;
			tri_indicesBuffer = context->createBuffer(RT_BUFFER_INPUT, RT_FORMAT_INT3, faces.size());
			norm_indicesBuffer = context->createBuffer(RT_BUFFER_INPUT, RT_FORMAT_INT3, faces.size());
			tex_indicesBuffer = context->createBuffer(RT_BUFFER_INPUT, RT_FORMAT_INT3, faces.size());
			mat_indicesBuffer = context->createBuffer(RT_BUFFER_INPUT, RT_FORMAT_INT, faces.size());

			positionsBuffer = context->createBuffer(RT_BUFFER_INPUT, RT_FORMAT_FLOAT3, vertices.size());
			normalsBuffer = context->createBuffer(RT_BUFFER_INPUT, RT_FORMAT_FLOAT3, normals.size());
			texcoordsBuffer = context->createBuffer(RT_BUFFER_INPUT, RT_FORMAT_FLOAT2, UVs.size());

			int3* tri_indices_ptr = (int3*)(tri_indicesBuffer->map());
			int3* norm_indices_ptr = (int3*)(norm_indicesBuffer->map());
			int3* tex_indices_ptr = (int3*)(tex_indicesBuffer->map());
			for (int i = 0; i < faces.size(); i++) {
				tri_indices_ptr[i].x = faces[i].v[0];
				tri_indices_ptr[i].y = faces[i].v[1];
				tri_indices_ptr[i].z = faces[i].v[2];
				
				norm_indices_ptr[i].x = faces[i].vn[0];
				norm_indices_ptr[i].y = faces[i].vn[1];
				norm_indices_ptr[i].z = faces[i].vn[2];

				tex_indices_ptr[i].x = faces[i].vt[0];
				tex_indices_ptr[i].y = faces[i].vt[1];
				tex_indices_ptr[i].z = faces[i].vt[2];
			}
			tri_indicesBuffer->unmap();
			norm_indicesBuffer->unmap();
			tex_indicesBuffer->unmap();

			int* mat_indices_ptr = (int*)(mat_indicesBuffer->map());
			for (int i = 0; i < faces.size(); i++) {
				mat_indices_ptr[i] = 0;
			}
			mat_indicesBuffer->unmap();

			float3* positions_ptr = (float3*)(positionsBuffer->map());
			for (int i = 0; i < vertices.size(); i++) {
				positions_ptr[i].x = scale * vertices[i].v[0];
				positions_ptr[i].y = scale * vertices[i].v[1];
				positions_ptr[i].z = scale * vertices[i].v[2];
			}
			positionsBuffer->unmap();

			float3* normals_ptr = (float3*)(normalsBuffer->map());
			for (int i = 0; i < normals.size(); i++) {
				normals_ptr[i].x = normals[i].vn[0];
				normals_ptr[i].y = normals[i].vn[1];
				normals_ptr[i].z = normals[i].vn[2];
			}
			normalsBuffer->unmap();

			float2* texcoords_ptr = (float2*)(texcoordsBuffer->map());
			for (int i = 0; i < UVs.size(); i++) {
				texcoords_ptr[i].x = UVs[i].vt[0];
				texcoords_ptr[i].y = UVs[i].vt[1];
			}
			texcoordsBuffer->unmap();
		}

		// ��������ʵ��
		geom_tri = context->createGeometryTriangles();
		geom_tri->setPrimitiveCount(faces.size());
		geom_tri->setTriangleIndices(tri_indicesBuffer, RT_FORMAT_UNSIGNED_INT3);
		geom_tri->setVertices(vertices.size(), positionsBuffer, RT_FORMAT_FLOAT3);
		// ��������ٽṹ�Ժ�Buffer����release
		geom_tri->setBuildFlags(RTgeometrybuildflags(0));
		pro_attri = context->createProgramFromPTXString(
			sutil::getPtxString(NULL, "triangle_mesh_1.cu"), "mesh_attributes");
		geom_tri->setAttributeProgram(pro_attri);

		// Ϊ�˼򵥣�������һ������
		size_t num_matls = 1;
		geom_tri->setMaterialCount(num_matls);
		geom_tri->setMaterialIndices(mat_indicesBuffer, 0, sizeof(unsigned), RT_FORMAT_UNSIGNED_INT);

		geom_instance = context->createGeometryInstance();
		geom_instance->setGeometryTriangles(geom_tri);

		// Set the materials
		geom_instance->setMaterialCount(num_matls);
		geom_instance->setMaterial(0, matl);
	
		// Put these on the GeometryInstance, not Geometry, to be compatible with the Triangle API.
		geom_instance["vertex_buffer"]->setBuffer(positionsBuffer);
		geom_instance["normal_buffer"]->setBuffer(normalsBuffer);
		geom_instance["texcoord_buffer"]->setBuffer(texcoordsBuffer);
		geom_instance["index_buffer"]->setBuffer(tri_indicesBuffer);
		geom_instance["normal_index_buffer"]->setBuffer(norm_indicesBuffer);
		geom_instance["tex_index_buffer"]->setBuffer(tex_indicesBuffer);
		geom_instance["material_buffer"]->setBuffer(mat_indicesBuffer);

		return true;
	}


};









#endif






